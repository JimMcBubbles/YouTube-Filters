To install and build locally:
1. Use node v22.18.0 (if you have nvm installed, simply run `nvm use`)
2. Make sure pnpm is installed
3. Run `pnpm install` to install all dependencies
4. Run `pnpm run build:firefox` to build the extension for Firefox
5. You will now have an exact built copy of the add-on as uploaded
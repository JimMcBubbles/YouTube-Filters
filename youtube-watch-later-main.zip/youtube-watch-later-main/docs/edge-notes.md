To use this addon:
1. Install and activate the addon
2. Go to www.youtube.com
3. Log in to your account
4. Find a button with clock icon on every video
5. Click the button to instantly add the video to your Watch Later playlist